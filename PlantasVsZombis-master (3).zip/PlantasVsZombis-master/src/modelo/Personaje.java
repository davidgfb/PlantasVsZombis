package modelo;
public class Personaje {
    
    public Personaje(int fila,int columna,String personaje) {Matriz.setElemento(fila,columna,personaje);}
}
